/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import javax.swing.*;
/**
 *
 * @author komputer jarkom 1
 */
public class Pangkat {
    public static void main(String[] args) {
        String bilangan = JOptionPane.showInputDialog("Isikan Bilangan");
        
        String pangkat = JOptionPane.showInputDialog("Isikan Pangkat");
        
        int bil = integer.parseInt(bilangan);
    }
}
