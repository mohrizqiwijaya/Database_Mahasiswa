public class arimatika {
    
    int x;
    int y;
    
    arimatika(int x, int y){
        this.x = x;
        this.y = y;
    }
    
    arimatika(){
        
    }
    
    void setXY(int x, int y){
        this.x = x;
        this.y = y;
    }
    
    int addNumber(){
        return x + y; 
    }
    
    int addNumber(int bil1, int bil2){
        return bil1 + bil2;
    }
    
    double addNumber(double bil1, double bil2){
        return bil1 + bil2;
    }
    
    @Override
    public String toString(){
        String hasil;
        hasil = "x : " + x + "  y : " + y;
        hasil += "\nHasil Penjumlahannya adalah :" + addNumber(x,y);
        return hasil;
    }
}