/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author komputer jarkom 1
 */
public class Loopfor {
    public static void main(String[] args) {
        for(int i=1;i<=10;i++){
            System.out.println(i +","); 
        }
        System.out.println("------kelipatan 10------");
        
        for(int i=10;i<=100;i=i+10){
        System.out.println(1 +",");
        }
        System.out.println("\n------10 sampai 1------");
        
        for(int i=10; i >=1;i--){
            System.out.println(1+",");
        }
        System.out.println("\n------1,-2, 3, 4 5,...------");
        
        int sign = 1;
        for(int i=1; i<=10; i++){
            System.out.println(i * sign);
            sign = sign * -1;
        }
    }
}
