public class perhitungan {
    private int sisi;
    private int panjang;
    private  int lebar;
    
    void setPL(int p, int l){
       panjang = p;
       lebar = l;
    }
    
    perhitungan(int p, int l){
       panjang = p;
       lebar = l;
    }
    
    perhitungan(){
    }
    
    int hitungLuasBujursangkar(int s){
        int luas = s * s;
        
        return luas;
    }
    
    int hitungLuasBujursangkar(int p, int l){
        int luas = p * l;
        
        return luas;
    }
}
