
public class ObjekMobil {
    
        public static void main(String args[]){
            Mobil m = new Mobil("honda",100,200);
            MobilDiesel md = new MobilDiesel ("fuso", 10, 10, "solar");
            m.info();
            md.info();
            
            MobilBensin mb = new MobilBensin ("avanza",20,20,"pertamax");
            mb.infoMobilBensin();
        }
}

