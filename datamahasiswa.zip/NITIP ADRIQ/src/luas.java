
public class luas {
    public static void main(String[] args) {
        bangunDatar Bujursangkar = new bangunDatar(5);
        bangunDatar persegiPanjang = new bangunDatar(2,3);
        
        int hasil1 = persegiPanjang.hitungLuas(5);
        int hasil2 = persegiPanjang.hitungKeliling(5);
        int hasil3 = Bujursangkar.hitungLuas(2, 3);
        int hasil4 = Bujursangkar.hitungKeliling(2, 3);
        
        
        System.out.println("keliling bujur sangkar = " + hasil3);
        System.out.println("luas bujur sangkar = " + hasil4);
        System.out.println("keliling persegi panjang = " + hasil2);
        System.out.println("luas persegi panjang = " + hasil1);
        System.out.println("");
    }   
    
}