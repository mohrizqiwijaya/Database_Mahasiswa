/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author komputer jarkom 1
 */
public class countVocal {
    public static void main(String[] args) {
        String Kampus = "Universitas Nusa Putra";
        System.out.println("    ");
        //Mengambil Karakter indeka ke 0
        System.out.println(Kampus.charAt (0));
        System.out.println(Kampus.charAt(1));
         System.out.println(Kampus.charAt(2));
         int jmla = 0;
         int jmli= 0;
         int jmlu= 0;
         int jmle= 0;
         int jmlo= 0;
         for(int i=0;i<Kampus.length();i++){
            
              if(Kampus.charAt(i)=='a'){
              jmla++;
              if(Kampus.charAt(i)=='i'){
              jmla++;
              if(Kampus.charAt(i)=='u'){
              jmla++;
              if(Kampus.charAt(i)=='e'){
              jmla++;
              if(Kampus.charAt(i)=='o'){
               jmla++;
            
             }
             else if(Kampus.charAt(i)=='u'){
                 jmlu++;
             }
             System.out.println("Jumlah Huruf A"+ jmla);
               System.out.println("Jumlah Huruf A"+ jmli);
                 System.out.println("Jumlah Huruf A"+ jmlu);
                   System.out.println("Jumlah Huruf A"+ jmle);
                     System.out.println("Jumlah Huruf A"+ jmlo);
                
             }
       }
}
