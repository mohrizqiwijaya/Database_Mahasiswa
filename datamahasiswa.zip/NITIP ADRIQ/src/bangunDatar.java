
public class bangunDatar {
   private int s;
   private int p;
   private int l;
   
   bangunDatar(int s){
       this.s = s;
   }
   
   bangunDatar(int p, int l){
       this.p = p;
       this.l = l;
   }
   
   int hitungLuas(int s){
       return s * s;
   }
   
   int hitungLuas(int p, int l){
       return p * l;
   }
   
   int hitungKeliling(int s){
       return s * 4;
   }
   
   int hitungKeliling(int p, int l){
       int kel = p + l;
       return 2 * kel;
   }
   
   
}
