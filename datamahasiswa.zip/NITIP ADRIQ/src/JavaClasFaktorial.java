
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author komputer jarkom 1
 */
public class JavaClasFaktorial {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Isikan Bilangan:");
        int bilangan = sc.nextInt();
        
        int hasil = 1;
        for(int i=1;i<=bilangan;i++){
          hasil = hasil * i;  
        }
        System.out.println(bilangan + "!=" + hasil);
    }  
}
